<?php
define('DOMAIN','http://gonzaapp.com');
define('SECRET_KEY',"6s7asdfasdf21123/**//");

// require 'functions.php';
require '../app/autoload.php';
require 'Request.php';
require 'Router.php';
require 'Database.php';
require 'Model.php';
require 'BaseController.php';
require 'View.php';
// require 'dataDB.php';

