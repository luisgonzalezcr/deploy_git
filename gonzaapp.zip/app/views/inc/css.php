<!-- tailwindcss -->
<link href="<?php echo DOMAIN ?>/plugins/bootstrapv5/css/bootstrap.min.css" rel="stylesheet" />

<!-- tailwindcss -->
<!-- <script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          clifford: '#da373d',
        }
      }
    }
  }
</script> -->




<!-- fontawesome 6 -->
<link href="<?php echo DOMAIN ?>/fontawesome/css/all.min.css" rel="stylesheet" />
<!-- css Personalizado -->
<link href="<?php echo DOMAIN ?>/css/main.css" rel="stylesheet" />