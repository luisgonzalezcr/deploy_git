<footer class="cantainer-fluid bg-dark bg-gradient p-0 m-0">

  <div class=" container">
    <div class="d-flex flex-column-reverse text-center text-md-start flex-md-row justify-content-between align-items-center text-white">
      <!-- derechos -->
      <div>
        @Todos los Derechos Reservados 🕓Luis Gonzalez
      </div>
      <!-- links -->
      <ul class="navbar-nav d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 bg-dark text-white mb-3 mb-md-0">
        <li class="nav-item footer_nav"><a class="nav-link" href="">Inicio</a></li>
        <li class="nav-item footer_nav"><a class="nav-link" href="">Cursos</a></li>
        <li class="nav-item footer_nav"><a class="nav-link" href="">Blog</a></li>
      </ul>
    </div>
  </div>

</footer>