<!-- banner -->
<!-- https://aca.gonzacr.com/academia/wp-content/uploads/2022/08/hero_action.png -->
<div class="container-fluid">
  <div class=" container">
    <div class="row">

        <!--Si quieres fondo oscuro encima de la imagen agregar .hero_action-->
      <div class="header_img" style=" background-image:url(<?php echo DOMAIN ?>/img/herader1.jpg);">

        <div id="dark_div" class="text-center text-md-start p-lg-5 m-lg-5 text-dark">

          <div  class="col-sm-12 col-md-8 col-lg-6 p-2 m-2 p-md-3 m-md-3 shadow-lg">
            <h2 class="fs-4">Despacio, pero con constancia</h2>
            <p class="fs-6">Intenta aprender durante 5 o 10 minutos al día.<a class="" href="https://aca.gonzacr.com/academia/pagina-del-escritorio/"> Continúa con el curso y alcanza todo tu potencial. </a></p>
            <div class="d-grid d-md-flex">
              <a href="https://aca.gonzacr.com/academia/cursos/" class="btn btn-warning btn-sm fw-bolder" type="button">Empezar Ahora</a>
            </div>


          </div>
        </div>
      </div>

    </div>
  </div>
</div>