
<script src="<?php echo DOMAIN ?>/plugins/bootstrapv5/js/bootstrap.bundle.min.js"></script>
<!-- fontawesome 6 -->
<script src="<?php echo DOMAIN ?>/fontawesome/js/all.min.js"></script>
<!-- darkMode -->
<script src="<?php echo DOMAIN ?>/js/darkMode.js"></script>
<script>
  console.log('sss');
</script>