<div class="container-fluid">

  <div class="container d-flex flex-column flex-md-row justify-content-between align-content-center align-items-center text-center gap-2 py-4 border-5 border-bottom border-danger">
    <span class="fw-semibold">
      El aprendizaje te puede abrir puertas| Empieza a avanzar hacia tus objetivos, la forma facil de aprender.
    </span>

    <ul class=" navbar-nav d-flex flex-row gap-5 align-items-center justify-content-center">

      <li class="nav-item">
        <a class="nav-link" target="_blank" href="https://facebook.com/luigonsa"><i class="fa-brands fa-facebook-f fw-bold fs-5"></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" target="_blank" href="https://twitter.com/lgonzacr"> <i class="fa-brands fa-twitter fw-bold fs-5"></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" target="_blank" href="https://bit.ly/3H6x2HC "><i class="fa-brands fa-youtube fw-bold fs-5"></i></i></a>

      </li>
      <li class="nav-item">
        <a class="nav-link" target="_blank" href=""><i class="fa-brands fa-linkedin fw-bold fs-5"></i></i></a>
      </li>

    </ul>


  </div>


</div>