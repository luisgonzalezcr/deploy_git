<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="<?php echo DOMAIN ?>/favicon/academia/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<meta name="description" content="Academia de Aprendizaje Gonzalez, cursos online, aprende desde la comodida de tu casa,La forma facil de aprender">
<meta name="keyword" content="Academia de aprendizaje Gonzalez,Academia,Aprendizaje,cursos, cursos online, aprende, aprende desde casa, forma facil de aprender">