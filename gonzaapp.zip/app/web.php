<?php

$router->add('/', 'HomeController::index');
$router->add('/productos', 'ProductsController::index');
// $router->add('/edit/:id', 'HomeController::edit');
// $router->add('/delete/:id', 'HomeController::delete');

// $router->add('/productos', 'ProductsController::index');
// $router->add('/producto/:name', 'ProductsController::show');
